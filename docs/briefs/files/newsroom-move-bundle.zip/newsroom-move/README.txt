Bundle for moving the SGit Newsroom from sgit.ai to newsroom.sgit.ai.

BRIEF.md       the brief (also at https://sgit.ai/docs/briefs/newsroom-move-to-newsroom-sgit-ai.html)
IMAGES.txt     every article image, card, banner and Open Graph image, by URL (not included)
admin/, assets/, articles/, newsroom/, .well-known/
               source, content, components and generated feeds, at their paths in the sgit.ai repository,
               as of site v0.7.36. Every file is also public at https://sgit.ai/<path>; fetch it there
               for the current version, because articles keep arriving until cutover.
