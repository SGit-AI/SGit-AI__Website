---
title: Pay to keep your persona: readers should pay because it helps them, not because they feel they should
date: 2026-10-10
time: 17:00
author: Dinis Cruz
author_url: about/index.html
summary: Most of what readers are asked to pay for, they pay for because they have to, because they are made to feel they should, or because it is the right thing to do. That works to a degree, and it does not scale. The value proposition we want is the opposite: a reader pays because it helps them, because what they are buying is time, context, focus, the ability to make good decisions and a better experience. On this site that thing now has a name. Your reading builds a persona, with a name and a graph you can watch grow, and you can have several, because a persona is a way to manage focus: one for security, one for AI development, one for everything else. Start from five made from what this site publishes, keep articles in a persona or put them out of it, and switch between them. Today it all lives in one browser, so opening the site on an iPad and then on a laptop gives you two strangers. That is the bad experience worth fixing, and the thing worth paying for: a persona that follows you to your phone, your laptop and your agent, with the privacy intact.
tags: newsroom, personalisation, personas, value-proposition, micropayments, local-first, privacy, focus, article
---

!shot gp-why.webp | images/ | Two ways to ask a reader for money. On the left, the reasons readers are asked to pay today; on the right, the things they would pay for because they help them, and the persona that carries them from device to device.

> **This page has noticed you.** Every article you read adds to a persona kept in your browser. [Your newsroom](/account/newsroom.html) shows it: its name, its picks, and its graph.

## In short

- **Nobody should pay out of guilt.** Paying because you have to, because you feel you should, or because it is the right thing to do works to a degree. It does not scale, and it is not what we want readers to feel.
- **Pay for what it does for you.** Time, context, focus, the ability to make good decisions, a streamlined way through, a better experience.
- **That thing is a persona.** Your reading builds one, with a name and a graph you can watch grow. Keep articles in it or put them out of it, and it changes.
- **You are more than one reader.** Add personas, one per kind of reading. Five are ready to start from: the founder, the journalist, the security lead, the AI builder, the board member. A persona is a way to manage focus.
- **Today a persona lives in one browser.** Open the site on an iPad, then on a laptop, and you are two strangers. That is not a cheat to worry about. It is a bad experience.
- **What people will pay for** is a persona that follows them, to their phone, their laptop and their agent, with the privacy intact.

## Three reasons readers are asked to pay, and why none of them is ours

There are three common reasons a reader pays for what they read, and most reader-funded publishing uses one of them.

**Because they have to.** The paywall. The Guardian's app, Press Gazette reported in September 2025, "sits within a paywall (free users can only read 20 articles per month)".

**Because they feel they have to.** The ask, the count of what you have read, the reminder that others pay. The Guardian's middle tier, at £12 a month, buys among other things the right to "avoid intrusive pop-up supporter messages". The feeling of being asked has a price, and the price is paid to make it stop.

**Because it is the right thing to do.** The donation. Wikipedia is the best example there is: the Wikimedia Foundation reports "over 8 million donors giving an average donation of $10.58" in its 2023-24 financial year. That is a remarkable achievement, and it is what one of the most visited sites in the world reaches by asking everybody, every year.

All three work, to a degree. My view, after trying versions of them, is that they do not scale for anyone who is not already enormous, and that they make the reader feel the wrong thing. "We don't want people to pay for content because they have to, because they feel they have to, because you shame them, because they feel they have a moral obligation." The reader should pay because paying helps them.

## What a reader is actually buying

Not the article. The article is free to read here, and it is free to read with the meter below zero. What a reader is buying, on this site and on most good ones, is:

- **time**, because they reach the thing worth reading sooner;
- **context**, because each piece arrives connected to what they already know;
- **focus**, because the site shows them their kind of reading and not everything;
- **the ability to make good decisions**, because the evidence comes with the argument;
- **a streamlined way through**, because what they have read, kept and dismissed is remembered;
- **a better experience**, because the site knows them back.

Each of those depends on the same asset: a record of what the reader read, how much of it, what they kept and what they rejected, organised so that the site can act on it. The [reading meter](/articles/going-live-with-the-reading-meter.html) already keeps that record, because a ledger has to. Since today it does something with it that the reader can see.

## The persona

Your reading builds a persona. It starts empty, and every page you read adds to it, weighted by how far down the page you read. It gets a name from the topics you read most, until you give it one of your own: read mostly about agents and policy and it is *The Policy Architect*; add graphs and it becomes *The Policy Architect, with a streak of the Cartographer*. It has a front page, [your newsroom](/account/newsroom.html), with the articles it would want next. And it has a graph: you in the middle, the topics you read around you, the pages behind each topic, and the citations between those pages.

!shot gp-newsroom.webp | images/ | Your newsroom, as one of the five starting personas: who it is, what it would read next, with a Keep and a "Not for this persona" on every pick.

You can steer it. Every pick in your newsroom has *Keep* and *Not for this persona*, and every article page has *Keep in your persona* at its foot. A kept article pulls its topics and tags up; a rejected one pushes them down and disappears from the picks. The graph moves when you do. This is the part that matters most, and it is small: the reader can see the model the site has of them, and change it.

!shot gp-graph.webp | images/ | A persona as a graph: the persona in the middle, its topics around it sized by weight, the pages behind each topic, and the citations between them. Filled dots were read, green ones kept, hollow ones came with the preset and are still unread.

## Personas are focus

One persona is not enough, and that is the second thing I learned building [The Cyber Boardroom](https://thecyberboardroom.com): once users try personalisation, they do not want one persona, they want several. I read about cyber security for one reason and about AI development for another, and the version of me that reads one is not interested in the other's picks. A persona is a way to manage focus. The more a reader can do with it, the more attached they become to it.

So you can have as many as you like. Each has its own picks, its own graph, and its own list of articles kept in or put out. What you read while a persona is active counts towards it; your default persona, built from everything you read, keeps counting everything. And so that nobody starts from nothing, there are five ready-made personas built from what this site has published:

| Persona | Starts from | For |
|---|---|---|
| Morgan, the founder | Strategy, pricing, security sized to the startup | Building a company: what to build, what to charge, what to secure and when to stop |
| Rowan, the journalist | News history, story vaults, local evidence | Where news came from, where it could go, and what publishers are owed by the machines that read them |
| Sam, the security lead | Insider risk, blast radius, identity, incidents | Agents as insiders, and the controls that hold when a model does not |
| Kai, the AI builder | Claude Code sessions, hooks, memory, behaviour policies | Making agents work day to day |
| Jordan, the board member | Business models, due diligence, risk acceptance, governance | How AI is changing the business, and how to govern it |

Each one starts from seven or eight articles and a few topics, and becomes yours as you read and curate. The names are made up and you can change them; [your personas](/account/personas.html) is where.

!shot gp-personas.webp | images/ | Your personas: the default one built from all your reading, the ones you added, and the five starting points not yet added.

## The iPad problem

I opened the site on my iPad this morning, and it worked well. The balance was in the top bar, the reading account was there, and the front page made sense. Then I thought about opening it on my laptop, and realised I would be a stranger there: a new balance, no history, no persona.

The first article on the meter called that a cheat: open a private window and you start again with £5.00. [Who will game the reading meter](/articles/who-will-game-the-reading-meter.html) explained why that does not matter, because the reader who does it was not going to pay anyway. But it is more interesting than that. The more a persona knows, the worse it is to lose it. Two devices, two strangers, is not a security gap; it is a bad user experience, and it gets worse exactly as the product gets better.

Today the only fix is manual: export your account as JSON on one device and restore it on the other, from [your reading account](/account/index.html#restore). It works, and it is clumsy on purpose, because it shows what is missing.

## What people will pay for

A persona that follows you. To your phone, to your laptop, and to your agent: when I connect to this site through Claude, the agent should read as my security persona when I am working on security, not as a stranger and not as everyone. That is the value proposition, and it is tight: people do not pay because they care about the site, and they should not feel guilty if they don't. They pay because they want to keep their persona, and to have it wherever they read.

The privacy angle does not go away when that happens; it is what makes it possible. The persona lives in the reader's browser today and nowhere else. When it moves, it moves into an [encrypted vault](/articles/what-sgit-is.html) whose key only the reader holds, so the site that stores it cannot read it, and the reader can take it elsewhere. The site pays for the storage it cannot read; the reader pays for the persona that lives in it.

## The question after that

If the persona is worth keeping, the next question is whether there is enough worth reading in it. There are about sixty articles on this site today, across six topics, and the five starting personas were chosen so that each has a real starting shelf. The better the graph of each article becomes, the better every persona built on it becomes, which is why the work on extracting more from each article, more facts, more connections, more ways to read it, matters to this as much as to the articles themselves. [One article, five readers](/articles/one-article-five-readers.html) is the first of it: a librarian, a cartographer, a historian, an explainer and a storyteller sent through each article after it is written, with every item anchored to its sentence.

## Help us design it

There is a faster way than waiting for numbers. Use the site as you normally would for a few days, then [send us your reading](/account/share.html): which pages, how far down each, what you kept, put out or declined. Dinis will reply with what your front page could look like, designed from your actual reading. The page shows you, word for word, everything that would be sent; you can copy it into an email or a message, or send it with your name and email, encrypted in your browser so that only our list agent can open it. It is the tightest feedback loop we have: real reading in, a real front page back.

## What we expect, written down now

These are added to the anchors in [going live with the reading meter](/articles/going-live-with-the-reading-meter.html), after its five were written and before the first payment. They cannot be tested until a persona can follow a reader between devices; they are here so that we cannot pretend later that we expected something else.

| # | Hypothesis | Proved wrong if |
|---|---|---|
| H6 | When a persona can follow a reader between devices for a price, more readers pay for that than top up the meter for reading alone | Fewer pay for the persona than for reading |
| H7 | Readers who have more than one persona pay more often than readers who have one | No difference, among readers who tell us |

## Try it

You have a persona already; [your newsroom](/account/newsroom.html) shows it. Add one of the five, keep a few articles, put one out, and watch the graph change. Then open the site on another device and see what you have to leave behind, or [send us your reading](/account/share.html) and we will design your front page from it.

---

*Written from a voice note by Dinis Cruz, who is the author of the idea and has editorial responsibility, by a Claude Code session working as the sgit.ai newsroom, on 10 October 2026. The quoted sentence about why people should not pay is his, from that note. The Guardian figures are from Press Gazette's report of 12 September 2025; the Wikipedia figure is from the Wikimedia Foundation's [2023-24 fundraising report](https://meta.wikimedia.org/wiki/Fundraising/2023-24_Report). Personas are in [SG Meter v1.1](/meter/index.html#personas); the five starting personas are `PERSONAS` in `admin/build/build_pages.py`, and the build refuses one that names an article that does not exist. The screenshots were taken from this site with a test history.*
